<?php

/*

Template Name: General Template

*/

?>

<?php get_header(); ?>
<img class="img-fluid"
    src="<?php header_image(); ?>" 
    alt="header" 
    height="<?php echo get_custom_header()->height; ?>"
    width="<?php echo get_custom_header()->width; ?>"
>

<div class="content-area">
    <main>
        <section class="middle-area">
            <div class="container">
                <div class="general-template">
                    <!-- News -->
                    <?php
                    if (have_posts()) :
                        while (have_posts()) : the_post();
                    ?>

                        <article>
                            <h2><?php the_title(); ?></h2>
                            <?php the_content(); ?>
                            <hr>
                        </article>

                        <?php
                        endwhile;
                    else :
                        ?>
                        <p><?php _e( 'There&rsquo;s nothing yet to be displayed...', 'wpcurso' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

<?php get_footer(); ?>